For contribution guidelines, see [doc:contributing].

[doc:contributing]: https://github.com/contiki-ng/contiki-ng/wiki/Contributing
